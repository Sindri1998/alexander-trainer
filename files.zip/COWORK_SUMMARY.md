# Alexander Machine Shop — G-Code Training Portal
## Cowork Project Handoff Summary

---

## What this project is

A React/Vite web app hosted at **alexandersmachineshoptraining.com** (on Netlify) that trains CNC machinists on G-code and M-codes for the **Doosan PUMA DNT2600M** lathe (Fanuc 0i-TF control, BMT55P live tool turret, C-axis).

---

## Current file structure

```
alexander-trainer/
├── index.html
├── package.json          ← react, react-dom, react-router-dom
├── vite.config.js
├── netlify.toml          ← build: npm run build, publish: dist, redirect /* → /index.html
└── src/
    ├── main.jsx          ← BrowserRouter wraps App
    ├── App.jsx           ← routing, shared nav, auth check, dark mode state
    ├── Auth.jsx          ← useAuth hook (localStorage), LoginScreen component
    ├── Trainer.jsx       ← G-code quiz trainer (the main app, 1372 lines)
    ├── Simulator.jsx     ← G-code editor + lathe material removal simulator
    ├── CourseTest.jsx    ← 40-question certification test, 5 sections, 80% to pass
    └── Leaderboard.jsx   ← leaderboard with 3 tabs (test score, quiz stats, streak)
```

---

## Routes

| URL | Component | Description |
|-----|-----------|-------------|
| `/` | Trainer | G-code quiz game with flashcard-style questions |
| `/gcodesim` | Simulator | G-code editor with live 2D lathe toolpath + material removal |
| `/test` | CourseTest | 40-question untimed certification test |
| `/leaderboard` | Leaderboard | Rankings across all users |

---

## Auth system (Auth.jsx)

- **No password** — users just type their name on first visit
- Name stored in `localStorage` key `ams_user` as `{ name, joinedAt }`
- `useAuth()` hook returns `{ user, ready, login, logout }`
- Login screen shows Alexander Machine Shop blue frame branding
- App.jsx checks `if (!user) return <LoginScreen />` after all hooks

---

## Branding & design

- **Company:** Alexander Machine Shop
- **Sub-brand badge:** RAD MFG (red `#ef4444` block + grey MFG)
- **Primary blue:** `#004990` (Lowe's blue) — used on header frame, nav bar, CTA buttons
- **Silver text on blue:** `#c8d8e8`
- **Dark/Light toggle:** persists in App.jsx `dark` state, passed as prop to all pages
- **Dark theme:** `#0d1117` bg, `#161b22` cards, `#30363d` borders
- **Light theme:** `#f0f4f8` bg, `#ffffff` cards, `#e2e8f0` borders
- Font: monospace throughout

---

## Score system — CURRENT STATE (needs upgrading)

### What exists now
Scores are stored in **localStorage only** — meaning each user only sees their own scores and nobody sees anyone else's. The leaderboard works but is per-device only.

### What needs to be built
Replace localStorage score storage with **Supabase** so all users share one central database and the leaderboard shows everyone's real scores.

---

## THE TASK: Integrate Supabase for shared leaderboard

### What you need from the user first
The user needs to:
1. Go to **supabase.com** and create a free account
2. Create a new project (any name, e.g. "ams-trainer")
3. Go to **Project Settings → API** and copy:
   - **Project URL** (looks like `https://xxxxxxxxxxxx.supabase.co`)
   - **anon public key** (long JWT string)
4. Give those two values to you

### Database table to create in Supabase

Create one table called `scores` with these columns:

```sql
create table scores (
  id            uuid default gen_random_uuid() primary key,
  name          text not null unique,
  quiz_correct  integer default 0,
  quiz_total    integer default 0,
  best_streak   integer default 0,
  best_test_score integer,
  test_passed   boolean default false,
  test_attempts integer default 0,
  last_test_date timestamptz,
  last_seen     timestamptz default now(),
  updated_at    timestamptz default now()
);

-- Allow public read and upsert (anon key is safe for this)
alter table scores enable row level security;
create policy "Public read" on scores for select using (true);
create policy "Public upsert" on scores for insert with check (true);
create policy "Public update" on scores for update using (true);
```

### npm package to install

```
npm install @supabase/supabase-js
```

### New file to create: src/supabase.js

```js
import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = 'PASTE_PROJECT_URL_HERE'
const SUPABASE_ANON_KEY = 'PASTE_ANON_KEY_HERE'

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
```

### Changes to Leaderboard.jsx

Replace the two exported functions `saveTrainerScore` and `saveTestScore` and the `loadBoard` function with Supabase versions:

```js
import { supabase } from './supabase.js'

export async function saveTrainerScore(userName, { correct, total, streak, best }) {
  // Upsert — insert if new user, update if existing
  const { data: existing } = await supabase
    .from('scores')
    .select('quiz_correct, quiz_total, best_streak')
    .eq('name', userName)
    .single()

  const newCorrect = (existing?.quiz_correct || 0) + correct
  const newTotal   = (existing?.quiz_total   || 0) + total
  const newStreak  = Math.max(existing?.best_streak || 0, best || streak || 0)

  await supabase.from('scores').upsert({
    name:         userName,
    quiz_correct: newCorrect,
    quiz_total:   newTotal,
    best_streak:  newStreak,
    last_seen:    new Date().toISOString(),
    updated_at:   new Date().toISOString(),
  }, { onConflict: 'name' })
}

export async function saveTestScore(userName, { testScore, testPassed, testDate }) {
  const { data: existing } = await supabase
    .from('scores')
    .select('best_test_score, test_passed, test_attempts')
    .eq('name', userName)
    .single()

  await supabase.from('scores').upsert({
    name:            userName,
    best_test_score: Math.max(existing?.best_test_score || 0, testScore),
    test_passed:     existing?.test_passed || testPassed,
    test_attempts:   (existing?.test_attempts || 0) + 1,
    last_test_date:  testDate,
    last_seen:       new Date().toISOString(),
    updated_at:      new Date().toISOString(),
  }, { onConflict: 'name' })
}
```

Replace the `loadBoard()` call inside the Leaderboard component's `useEffect` with:

```js
useEffect(() => {
  supabase
    .from('scores')
    .select('*')
    .order('best_test_score', { ascending: false })
    .then(({ data }) => {
      if (data) {
        // Convert array to object keyed by name to match existing board shape
        const obj = {}
        data.forEach(row => {
          obj[row.name] = {
            name:          row.name,
            quizCorrect:   row.quiz_correct,
            quizTotal:     row.quiz_total,
            bestStreak:    row.best_streak,
            bestTestScore: row.best_test_score,
            testPassed:    row.test_passed,
            testAttempts:  row.test_attempts,
            lastTestDate:  row.last_test_date,
            lastSeen:      row.last_seen,
          }
        })
        setBoard(obj)
      }
    })
}, [tick])
```

Also set up a **Supabase real-time subscription** so the leaderboard updates live without polling:

```js
useEffect(() => {
  const channel = supabase
    .channel('scores-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'scores' }, () => {
      setTick(t => t + 1) // triggers the fetch useEffect
    })
    .subscribe()
  return () => supabase.removeChannel(channel)
}, [])
```

Remove the 5-second polling interval (`setInterval`) since real-time replaces it.

---

## Important technical notes

### React hook rules
ALL `useState` hooks in `App.jsx` must be declared at the top of the function before ANY conditional returns. This was a previous bug (React error #300). Do not put `if (screen === 'teach') return` before all hooks are declared.

### Theme system
Both Trainer.jsx and Simulator.jsx accept `dark` and `setDark` as props from App.jsx. They have a fallback internal state:
```js
const [_dark, _setDark] = useState(darkProp)
const dark = setDarkProp ? darkProp : _dark
const setDark = setDarkProp ?? _setDark
```
Do not remove this pattern.

### X = diameter on lathe
All X coordinates in the G-code database and simulator are in **diameter** (not radius). This is correct Fanuc lathe behaviour.

### Score submission timing
`saveTrainerScore` is called after every single quiz answer in Trainer.jsx inside the `check()` function. This means it fires frequently — the Supabase upsert must be non-blocking (fire and forget is fine, no await needed in the UI thread).

### Course test progress
Test progress is still saved to localStorage (key: `ams_test_progress_${userName}`) during the test itself — this is intentional so they can resume mid-test. Only the final score goes to Supabase.

---

## Deploy process

```bash
npm install
npm run build
# drag dist/ to netlify.com/drop
# OR push to GitHub → Netlify auto-deploys
```

`netlify.toml` already contains the SPA redirect rule — no changes needed there.

---

## Summary of files to touch for the Supabase task

| File | What to do |
|------|-----------|
| `src/supabase.js` | CREATE — Supabase client init with URL + anon key |
| `src/Leaderboard.jsx` | EDIT — replace localStorage with Supabase reads/writes + realtime |
| `package.json` | EDIT — add `@supabase/supabase-js` dependency |
| All other files | NO CHANGES needed |

---

*Alexander Machine Shop · RAD MFG · PUMA DNT2600M G-Code Training Portal*
*Built with React 18 + Vite 5 + React Router 6 + Supabase*
